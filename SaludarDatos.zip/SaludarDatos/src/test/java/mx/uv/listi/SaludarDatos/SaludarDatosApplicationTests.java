package mx.uv.listi.SaludarDatos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludarDatosApplicationTests {

	@Test
	void contextLoads() {
	}

}
